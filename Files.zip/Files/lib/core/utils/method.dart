class Method{

  static const getMethod='get';
  static const postMethod='post';
  static const updateMethod='update';
  static const deleteMethod='delete';

}